/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package laboratorio201;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

/*
UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO
CENTRO UNIVERSITARIO UAEM ZUMPANGO
INGENIERIA EN COMPUTACION
PROGRAMACION AVANZADA 2018-B

DESCRIPCION: 

FECHA: 
ALUMNO: OMAR ZAMORA RAMON
PROFESOR: ASDRÚBAL LÓPEZ CHAU
*/
/**
 *
 * @author HP
 */
public class PersonaFx {
    
    private SimpleStringProperty nombre = new SimpleStringProperty();
    private SimpleStringProperty paterno = new SimpleStringProperty();
    private SimpleStringProperty materno= new SimpleStringProperty();
    private SimpleStringProperty fecha= new SimpleStringProperty();
    private SimpleStringProperty genero= new SimpleStringProperty();

    public SimpleStringProperty getNombre() {
        return nombre;
    }

    public void setNombre(SimpleStringProperty nombre) {
        this.nombre = nombre;
    }

    public SimpleStringProperty getPaterno() {
        return paterno;
    }

    public void setPaterno(SimpleStringProperty paterno) {
        this.paterno = paterno;
    }

    public SimpleStringProperty getMaterno() {
        return materno;
    }

    public void setMaterno(SimpleStringProperty materno) {
        this.materno = materno;
    }

    public SimpleStringProperty getFecha() {
        return fecha;
    }

    public void setFecha(SimpleStringProperty fecha) {
        this.fecha = fecha;
    }

    public SimpleStringProperty getGenero() {
        return genero;
    }

    public void setGenero(SimpleStringProperty genero) {
        this.genero = genero;
    }
    
    

    @Override
    public String toString() {
        return nombre.getValue()+" "+paterno.getValue()+" "+materno.getValue()+" Date:"+fecha.getValue();
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio201;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author HP
 */
public class FXMLDocumentController implements Initializable {
    
    SimpleStringProperty name = new SimpleStringProperty();
    SimpleStringProperty patern = new SimpleStringProperty();
    SimpleStringProperty matern= new SimpleStringProperty();
    SimpleStringProperty date= new SimpleStringProperty();
    SimpleStringProperty gener= new SimpleStringProperty();
    
    PersonaFx p = new PersonaFx();
    
    private int idioma =0;

    public int getIdioma() {
        return idioma;
    }

    public void setIdioma(int idioma) {
        this.idioma = idioma;
    }
    
    private Stage stage;
    
    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }
    
    
    @FXML // fx:id="nombre"
    private Label nombre; // Value injected by FXMLLoader

    @FXML // fx:id="paterno"
    private Label paterno; // Value injected by FXMLLoader

    @FXML // fx:id="materno"
    private Label materno; // Value injected by FXMLLoader

    @FXML // fx:id="fecha"
    private Label fecha; // Value injected by FXMLLoader

    @FXML // fx:id="genero"
    private Label genero; // Value injected by FXMLLoader

    /*@FXML // fx:id="selectLenguaje"
    private ComboBox<?> selectLenguaje; // Value injected by FXMLLoader
    */
    @FXML
    ObservableList<String> options = 
    FXCollections.observableArrayList(
        "Español",
        "Ingles",
        "Frances",
        "Chino",
        "Aleman"
    );
    final ComboBox selectLenguaje = new ComboBox(options);

    @FXML // fx:id="txtName"
    private TextField txtName; // Value injected by FXMLLoader

    @FXML // fx:id="txtPaterno"
    private TextField txtPaterno; // Value injected by FXMLLoader

    @FXML // fx:id="txtMaterno"
    private TextField txtMaterno; // Value injected by FXMLLoader

    @FXML // fx:id="calendario"
    private DatePicker calendario; // Value injected by FXMLLoader

    @FXML // fx:id="hombre"
    private RadioButton hombre; // Value injected by FXMLLoader

    @FXML // fx:id="mujer"
    private RadioButton mujer; // Value injected by FXMLLoader

    @FXML // fx:id="boton"
    private Button boton; // Value injected by FXMLLoader
 
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        name.bindBidirectional(txtName.textProperty());
        p.getNombre().bindBidirectional(txtName.textProperty());
        patern.bindBidirectional(txtPaterno.textProperty());
        p.getNombre().bindBidirectional(txtPaterno.textProperty());
        matern.bindBidirectional(txtMaterno.textProperty());
        p.getNombre().bindBidirectional(txtMaterno.textProperty());
        
    }    

    
    
    
}
